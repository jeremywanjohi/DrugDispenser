const express = require('express');
const mysql = require('mysql');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cors = require('cors'); // Add this line


const app = express();
const PORT = 8080;

const secretKey = 'e8d0f848dbcba7ea2d56bb6915bea062'
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: null, // Your MySQL password
  database: 'patientdet',
  connectionLimit: 10,
});

app.use(express.json());
app.use(cors()); // Enable CORS for all routes


// Endpoint for generating an API token (admin or any user)
app.post('/generate-token', async (req, res) => {
  try {
    const { email } = req.body;

    // Check if the email is not an empty string
    if (email.trim() === '') {
      return res.status(400).json({ error: 'Email cannot be empty' });
    }

    // Retrieve user details from the database
    pool.getConnection((err, connection) => {
      if (err) {
        console.error('Error connecting to MySQL:', err.message);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      connection.query('SELECT * FROM patientdet WHERE email = ?', [email], (err, user) => {
        connection.release(); // Release the connection

        if (err) {
          console.error('Error querying MySQL:', err.message);
          return res.status(500).json({ error: 'Internal Server Error' });
        }

        // Check if the user exists
        if (user.length === 0) {
          return res.status(404).json({ error: 'User not found' });
        }

        // Generate an API token for the user
        const token = jwt.sign({ username: user[0].username, category: user[0].category, email: user[0].email }, secretKey, {
          expiresIn: '1h',
        });

        res.json({ token });
      });
    });
  } catch (error) {
    console.error('Error generating token:', error.message);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
